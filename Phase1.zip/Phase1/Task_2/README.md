# Security Report Generator

## Objective
A Python utility to check system properties and generate a timestamped security report.

## Features
- Automatically creates a text-based security report file
- Displays system OS and CPU core details
- Provides basic security hardening recommendations

## Requirements
- Python 3.x

## How to Run
```bash
python tool.py -g