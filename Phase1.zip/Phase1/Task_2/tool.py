import sys
import os
import datetime

def help_menu():
    print("Usage: python tool.py [option]")
    print("-h : show help")
    print("-g : generate security report")

def make_report():
    print("Generating security audit report...")
    filename = f"report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    
    try:
        with open(filename, "w") as f:
            f.write("=== SECURITY AUDIT REPORT ===\n")
            f.write(f"Date: {datetime.datetime.now()}\n\n")
            f.write("1. System Details:\n")
            f.write(f" - OS Name: {os.name}\n")
            f.write(f" - CPU Cores: {os.cpu_count()}\n\n")
            f.write("2. Basic Recommendations:\n")
            f.write(" - Keep system updated\n")
            f.write(" - Use strong passwords\n")
        print(f"Report saved successfully as: {filename}")
    except Exception as e:
        print(f"Error: {e}")

if len(sys.argv) > 1:
    arg = sys.argv[1]
    if arg == "-h":
        help_menu()
    elif arg == "-g":
        make_report()
    else:
        print("Invalid option. Use -h for help.")
else:
    make_report()