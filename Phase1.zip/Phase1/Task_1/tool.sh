#!/bin/bash

# Simple Linux Security Checker Tool

show_usage() {
    echo "Usage: ./tool.sh [option]"
    echo "-h : help menu"
    echo "-s : run security check"
}

check_system() {
    echo "--- System Details ---"
    echo "Hostname: $(hostname)"
    echo "Kernel: $(uname -r)"
    echo "Uptime: $(uptime -p)"
    echo ""

    echo "--- User Check ---"
    echo "Total users: $(wc -l < /etc/passwd)"
    echo "Users with shell access:"
    grep -v '/nologin\|/false' /etc/passwd | cut -d: -f1
    echo ""

    echo "--- Firewall Status ---"
    if command -v ufw > /dev/null; then
        sudo ufw status
    else
        echo "UFW is not installed on this system."
    fi
    echo ""

    echo "--- Open Ports ---"
    ss -tuln 2>/dev/null || netstat -tuln 2>/dev/null
}

# Checking arguments
if [ "$1" == "-h" ]; then
    show_usage
elif [ "$1" == "-s" ] || [ -z "$1" ]; then
    check_system
else
    echo "Invalid option. Use -h for help."
    exit 1
fi