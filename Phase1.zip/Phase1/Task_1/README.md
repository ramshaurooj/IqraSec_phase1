# Linux Security Checker

## Objective
A simple Bash-based security auditor to check system details, users, and active ports.

## Features
- Displays system info, hostname, kernel version, and uptime
- Checks total users and users with shell access
- Checks UFW Firewall status
- Scans open listening network ports

## Requirements
- Linux OS (Ubuntu/Debian recommended)
- Bash shell

## How to Run
```bash
chmod +x tool.sh
./tool.sh -s